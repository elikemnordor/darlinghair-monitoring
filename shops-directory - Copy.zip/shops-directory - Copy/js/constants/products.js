// Product constants for outlet validation
export const PRODUCTS = [
  { code: 'Product_A', name: 'Product A' },
  { code: 'Product_B', name: 'Product B' },
  { code: 'Product_C', name: 'Product C' },
];
